Author Varaidzo Nyoka Date: 2021/05/17_____________________________________Basic Introduction-------------------------------------
1. UNDERSTANDING DATA PROCESSING:
In this chapter, I learnt how to bind data to DOM elements and create new elements based on my data.
Through this experiment, I learnt how to use D3 for basic data visualization .
I understood the application scenarios of different types of charts.
On the basis of using the method provided by D3 to read external data files asynchronously, and using the API provided by D3 to draw different types of charts: bar chart, line chart, pie chart, force oriented chart, tree chart, map, etc.

_____________________________________Running the program-------------------------------------
Use Google Chrome, Visual Studio code_____________________________________Requirement-------------------------------------VSCode
Web browser
macOS or Linux or Windows____________________________________Install-------------------------------------The project uses D3.js, Charts and Drawings.Code Referenceshttps://stackoverflow

REFERENCES

Evans Muchinguri

https://www.kaggle.com/datasets
https://stackoverflow.com/questions/22933855/convert-csv-to-netcdf
https://towardsdatascience.com/handling-netcdf-files-using-xarray-for-absolute-beginners-111a8ab4463f
Github.com
Youtube tutorialsThis program is not for commercial use----------------------------------------